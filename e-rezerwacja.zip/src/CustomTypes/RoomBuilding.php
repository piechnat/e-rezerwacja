<?php

namespace App\CustomTypes;

abstract class RoomBuilding extends CustomType
{
    const GDANSKA = 'RB_GDANSKA';
    const IGO_MAJA = 'RB_IGO_MAJA';
    const ZUBARDZKA = 'RB_ZUBARDZKA';

    protected const VALUES = [
        self::GDANSKA => 'Gdańska 32',
        self::IGO_MAJA => '1-go Maja 4',
        self::ZUBARDZKA => 'Żubardzka 2a',
    ];
}