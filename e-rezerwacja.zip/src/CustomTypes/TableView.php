<?php

namespace App\CustomTypes;

class TableView
{
    private const MIN = 6;
    private const MAX = 22;

    public $headers = [];
    public $columns = [];
    public $meta = [];

    public function __construct(array &$headers, array &$columns)
    {
        if (count($headers) !== count($columns)) {
            throw new \InvalidArgumentException();
        }
        $this->headers = $headers;
        $this->columns = $columns;

        // set hours boundaries
        $min = $this::MIN;
        $max = $this::MAX;
        foreach ($this->columns as $key => &$items) {
            if (0 === count($items)) {
                continue;
            }
            $day = $this->headers[$key]['date']->format('j');
            $rsvn = reset($items);
            if ($rsvn['begin_time']->format('j') !== $day) {
                $min = 0;
            } else {
                $min = min($min, (int) $rsvn['begin_time']->format('G'));
            }
            $rsvn = end($items);
            if ($rsvn['end_time']->format('j') !== $day) {
                $max = 24;
            } else {
                $max = max($max, ((int) $rsvn['end_time']->format('G')) + (
                    $rsvn['end_time']->format('i') !== '00' ? 1 : 0
                ));
            }
            if (0 === $min && 24 === $max) {
                break;
            }
        }
        $this->meta = ['min_hour' => $min, 'max_hour' => $max];

        // set css dimensions
        foreach ($this->columns as $key => &$items) {
            foreach ($items as &$rsvn) {
                $base = $this->headers[$key]['date']->setTime($this->meta['min_hour'], 0);
                $rsvn['css_top'] = $this->secDiff($base, $rsvn['begin_time']) / 960;
                $rsvn['css_height'] = $this->secDiff($rsvn['begin_time'], $rsvn['end_time']) / 960;
            }
        }
    }

    private function secDiff(\DateTimeInterface $d1, \DateTimeInterface $d2): int
    {
        return ($d2->getTimestamp() - $d1->getTimestamp()) +
               ($d2->getOffset() - $d1->getOffset()); // ignore daylight savings time
    }
}
