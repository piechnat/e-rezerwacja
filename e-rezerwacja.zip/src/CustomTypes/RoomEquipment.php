<?php

namespace App\CustomTypes;

abstract class RoomEquipment extends CustomType
{
    const ORGAN = 'RQ_ORGAN';
    const HARPSICHORD = 'RQ_HARPSICHORD';
    const UPRIGHT_PIANO = 'RQ_UPRIGHT_PIANO';
    const DIGITAL_PIANO = 'RQ_DIGITAL_PIANO';
    const GRAND_PIANO = 'RQ_GRAND_PIANO';
    const SECOND_PIANO = 'RQ_SECOND_PIANO';
    
    protected const VALUES = [
        self::ORGAN => 'Organy',
        self::HARPSICHORD => 'Klawesyn',
        self::UPRIGHT_PIANO => 'Pianino',
        self::DIGITAL_PIANO => 'Pianino cyfrowe',
        self::GRAND_PIANO => 'Fortepian',
        self::SECOND_PIANO => 'Drugi fortepian',
    ];
}